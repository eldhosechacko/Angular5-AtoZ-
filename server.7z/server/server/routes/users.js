var express = require('express');
var router = express.Router();

/*controller*/
var controller = require('../controllers/users');


/*routes*/
router.post('/login/', controller.authenticate);
router.post('/users/', controller.userList);
router.post('/user-details/', controller.userDetails);


module.exports = router;