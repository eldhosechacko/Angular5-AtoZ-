var express = require('express');
var router = express.Router();

/*controller*/
var controller = require('../controllers/items');


/*routes*/
router.post('/items/', controller.itemList);
router.post('/item-details/', controller.itemDetails);


module.exports = router;