module.exports = {

    'secret': 'ilovescotchyscotch',
    'database': 'mongodb://localhost/Tododb'

};