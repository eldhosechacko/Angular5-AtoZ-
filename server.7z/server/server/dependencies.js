module.exports = function (app) {

    var express = require('express');
    var bodyParser = require('body-parser');

    app.use(express.static('www'));
    app.use(express.static('vendor'));
    app.use(express.static('www/app/components/navbar'));
    app.use(express.static('www/app/components/treeview'));

    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: false }));


    /* users call */
    var users = require('./routes/users');
    app.use('/api/users',
		function (req, res, next) {
		    return next();
		}, users);

	/* items call */
    var items = require('./routes/items');
    app.use('/api/items',
		function (req, res, next) {
		    return next();
		}, items);


}
