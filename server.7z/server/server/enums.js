module.exports = {
  externalConnectTypes: {
    serviceNow: 1,
    TFS: 2,
    JIRA: 3
  }
}
