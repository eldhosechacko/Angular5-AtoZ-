/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema,
  crypto = require('crypto'),
  _ = require('lodash');



/**
 * User Schema
 */

var ItemSchema = new Schema({
 item_id: {
    type: String,
    Required: 'Kindly enter the name of the task'
  },
  item_name: {
    type: String
  },
  item_description: {
    type: String
  },
  amount: {
    type: String,
    default: ['']
  },
   from_date: {
    type: Date,
     default: Date.now
  },
  to_date: {
    type: Date,
     default: Date.now
  },
   status: {
    type: String,
      default: ['Available']
  }
});




module.exports = mongoose.model('Item', ItemSchema);