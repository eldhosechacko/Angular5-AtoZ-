/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema,
  crypto = require('crypto'),
  _ = require('lodash');



/**
 * User Schema
 */

var UserSchema = new Schema({
 name: {
    type: String,
    Required: 'Kindly enter the name of the task'
  },
  created_date: {
    type: Date,
    default: Date.now
  },
  email: {
    type: String,
    default: [''],
	unique: true
  },
  password: {
    type: String,
    default: ['']
  },
   last_login: {
    type: Date,
     default: Date.now
  },
  status: {
    type: String,
    default: ['pending']
  }
});




module.exports = mongoose.model('User', UserSchema);