var mongoose = require('mongoose');

var Item = require('../models/item.js');

exports.itemList = function (req, res, next) {
	Item.find({}, function(err, itemList) {
		if (err)
		res.send(err);
		res.json(itemList);
	});
};

exports.itemDetails = function (req, res, next) {
	Item.find({_id:req.body._id}, function(err, itemDetails) {
		if (err)
		res.send(err);
		res.json(itemDetails);
	});
};

