var mongoose = require('mongoose');
var jwt    = require('jsonwebtoken');
var User = require('../models/user.js');
var config = require('../config');
var crypto = require('crypto');

exports.signout = function (req, res) {
    req.logout();
    res.redirect('/');
};


exports.authenticate = function (req, res, next) {
	var hashedPassword = crypto.pbkdf2Sync(req.body.password, "5765", 10000, 64, 'sha1').toString('base64');
	User.findOne({email:req.body.username,password:hashedPassword}, function(err, login) {
		if (err){
			res.send(err);
		}else{
			if(login){
			const payload = {admin: login.name };
			var token = jwt.sign(payload, config.secret, {
			//expiresInMinutes: 1440 
			});
			
			res.json({
				user:login,
				token:token
			});
			}else{
				res.json({"status":"failed","message":"Invalid login credentials..!"});
			}
		}
	});
};

exports.userList = function (req, res, next) {
	User.find({}, function(err, userList) {
		if (err)
		res.send(err);
		res.json(userList);
	});
};

exports.userDetails = function (req, res, next) {
	User.find({_id:req.body._id}, function(err, userDetails) {
		if (err)
		res.send(err);
		res.json(userDetails);
	});
};

