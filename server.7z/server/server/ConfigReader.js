﻿var fs = require('fs');
var SecureConf = require('secure-conf');
var sconf      = new SecureConf();

module.exports.getConfig = function(keyFile){
	var environment = process.env.NODE_ENV;
	var content = undefined;
	if(environment === 'production' && keyFile && fs.existsSync(keyFile)){
		var key = fs.readFileSync(keyFile, 'utf8');
		var path = 'config/production.json.enc';
		if(fs.existsSync(path) && key){
			content = sconf.decryptContent(fs.readFileSync(path, 'utf8'), key);
		}
		else{
			content = fs.readFileSync('config/default.json', 'utf8');
		}
	}
	else{
		var path = 'config/' + environment + '.json';
		if(environment && fs.existsSync(path)){
			content = fs.readFileSync(path, 'utf8');
		}
		else{
			content = fs.readFileSync('config/default.json', 'utf8');
		}
	}
	return JSON.parse(content);
}

module.exports.encryptConfig = function(file, keyFile){
	if(keyFile && fs.existsSync(keyFile)){
		var key = fs.readFileSync(keyFile, 'utf8');		
		var config = fs.readFileSync(file, 'utf8');
		fs.writeFileSync('D:/EdgeConnectTFS/EdgeConnect/Source/Web/config/file.txt', sconf.encryptContent(config, key));// sconf.encryptContent(config, key));
		return true;
	}
	else{
		return false;
	}
}