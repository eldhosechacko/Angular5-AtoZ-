var express = require('express');
var bodyParser = require('body-parser');
var expressValidator = require('express-validator');
var passport = require('passport');
var mongoose = require('mongoose');
var jwtauth = require('./jwtauth.js');
var config = require('./config'); // get our config file
var http = require('http');
var port = process.env.PORT || 5000;
var app = express();

mongoose.Promise = global.Promise;
global.sessionTimeout = 120;
global.sourceKey = '578344BD313E75640C6B4E31'; 
app.set('superSecret', config.secret); // secret variable

app.use(function(req,res,next){
	 jwtauth.authorize(req, res, next);
});
app.use(function (req, res, next) {	
    res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Credentials", "true");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,x-access-token,platform,Pragma,Expires,Cache-Control");
    res.header("Access-Control-Allow-Methods", "DELETE, GET, HEAD, POST, PUT, OPTIONS, TRACE");
    res.header("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type,authorization, Access-Control-Request-Method, Access-Control-Request-Headers"); 
    next();
});

app.use(bodyParser.urlencoded({limit: '10mb', extended: true}));
app.use(bodyParser.json({limit: '10mb'}));
app.use(expressValidator());
app.use(passport.initialize());
app.use(passport.session());
app.use(function(req,res,next){setTimeout(next,1000)});
var options = {};
var server = require('http').createServer(app);
server.listen(port, function (err) {
     console.log('Running server on port ' + port);
 });
var dependencies = require('./dependencies')(app);
var mongoose = require('mongoose');

mongoose.connect(config.database, function (err) {
    if (err) {
        console.log('connection error', err);
    } else {
        console.log('connection successful');
        mongoose.connection.on('disconnected', function (ref) {
            var child_process = require('child_process');
            child_process.exec('E:/Applications/autoStart/restart/restartNpm.bat', function (error, stdout, stderr) {
                console.log(error);
                console.log(stdout);
                console.log(stderr);
            });
            console.log('disconnected from mongo server.');
        });
    }
});

module.exports = app;
