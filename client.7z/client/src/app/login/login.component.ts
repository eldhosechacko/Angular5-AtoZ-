import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/services/user.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { routerTransition } from '../router.animations';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    animations: [routerTransition()]
})
export class LoginComponent implements OnInit {

    public loggedUser: any;
    public logoPath;
    public errMessage;
    constructor(public router: Router, private userService : UserService) { this.logoPath   ="assets/logo.png";}

    ngOnInit() {
       
    }


    OnSubmit(userName,password){
       
        document.getElementById("loader").removeAttribute("style");
        var user=   {"username":userName,"password":password}

        this.userService._login(user).subscribe((data : any)=>{

            document.getElementById("loader").setAttribute("style", "display:none;");
            this.loggedUser     =   JSON.stringify(data.user);
           
            
            if(this.loggedUser){
                localStorage.setItem('auth_token',data.token);
                localStorage.setItem('loggedUser',this.loggedUser);
                this.onLoggedin();
                this.router.navigate(['/dashboard']);
            }else{
                this.errMessage =  JSON.stringify(data.message); 
            }
            
       },
       (err : HttpErrorResponse)=>{
        this.errMessage =  "Login attempt failed. Please try again later."; 
       });
     }

    onLoggedin() {
        localStorage.setItem('isLoggedin', 'true');
    }
}
