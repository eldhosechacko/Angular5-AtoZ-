import { Injectable } from '@angular/core';
import {HttpService} from './http.service';

@Injectable()
export class UserService {
  readonly rootUrl = 'http://localhost:5000/api/';
  constructor(private http: HttpService) { }

_login(user) {
    var data   =   JSON.stringify(user);
    return this.http.post(this.rootUrl + 'users/login',data).map((res) => {
      return res.json();
    });
  }
/*
  _users() {
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json;charset=utf-8'});
    return this.http.post(this.rootUrl + 'users/users',  { headers: reqHeader });
  }

  _userDetails(user){
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json;charset=utf-8'});
    return this.http.post(this.rootUrl + 'users/user-details', user, { headers: reqHeader });
  }

  getUserClaims(){
   return  this.http.get(this.rootUrl+'/api/GetUserClaims');
  }
  */

}
