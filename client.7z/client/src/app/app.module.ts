import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HttpClient } from '@angular/common/http';

import { HttpModule, RequestOptions, XHRBackend } from '@angular/http';
import { HttpService } from './shared/services/http.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './shared';
import { UserService } from './shared/services/user.service';
import { ItemsService } from './core/items/items.service';
import { PagerService } from './core/components/pagination/index'



@NgModule({
    imports: [
        CommonModule,
        BrowserModule,
        BrowserAnimationsModule,
        HttpClientModule,
        HttpModule,
        AppRoutingModule
    ],
    declarations: [AppComponent],
    providers: [AuthGuard,UserService,ItemsService,PagerService,{
        provide: HttpService,
        useFactory: (backend: XHRBackend, options: RequestOptions) => {
          return new HttpService(backend, options);
        },
        deps: [XHRBackend, RequestOptions]
      }],
    bootstrap: [AppComponent]
})
export class AppModule {}
