import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule }   from '@angular/forms';

import { CoreRoutingModule } from './core-routing.module';
import { CoreComponent } from './core.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';
import { ProfileComponent } from './profile/profile.component';
import { PageHeaderModule } from './../shared';

@NgModule({
    imports: [
        CommonModule,
        CoreRoutingModule,PageHeaderModule,FormsModule,      
        NgbDropdownModule.forRoot()
    ],
    declarations: [CoreComponent, SidebarComponent, HeaderComponent, ProfileComponent]
})
export class CoreModule {}
