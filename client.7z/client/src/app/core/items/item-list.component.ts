import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { ItemsService } from './items.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

import { PagerService } from '../components/pagination/index'

@Component({
    selector: 'app-items',
    templateUrl: './item-list.component.html',
    styleUrls: ['./items.component.scss'],
    animations: [routerTransition()]
})
export class ItemListComponent implements OnInit {
    public items: any;
    public sortItem: any;
    public message: string="";
    public amountSortIcon;
    public sortDirection="up";
    public loader = false;
    
    constructor(private itemsService : ItemsService,private pagerService: PagerService) {}

    

    // array of all items to be paged
    private allItems: any[];

    // pager object
    pager: any = {};

    // paged items
    pagedItems: any[];

    ngOnInit(){
       this.itemList();
     }

     /*listing page*/
     itemList(){
         this.loader    =   true;
        this.itemsService._itemList().subscribe((data : any)=>{
            this.loader    =   false;
            console.log(data._body);
            this.items =   data;
            if(this.items!=0){
                // set items to json response
                this.allItems = data;

                // initialize to page 1
                this.setPage(1);
            }else{
                this.message="No data found";
            }  
       },
       (err : HttpErrorResponse)=>{
       });
     }

    

    /*data filtering*/
    filter(key,term: string){  
        var sortedItems = [];
         for(var i=0;i<=this.items.length;i++){
            if(this.items[i]){
             if(this.items[i][key].match(term)){
                sortedItems.push(this.items[i]);
             }
            }
         }
       //  return this.allItems;
       this.allItems    =   sortedItems;
       this.setPage(1);
     }

     /*page sorting*/
     sort(sortItem,sortDirection,event){ 
        
        //clear sirter for all columns
        var elems = document.querySelectorAll(".sorter");
        [].forEach.call(elems, function(el) {
            el.classList.remove("fa-sort-down");
            el.classList.remove("fa-sort-up");
            el.classList.add("fa-sort");
        });
        
        //switch sort class and icons then sort
        if(sortDirection=="up"){
            event.target.classList.remove("fa-sort-up");
            event.target.classList.add("fa-sort-down");
            this.sortDirection="down";
            this.allItems.sort(function(a,b) {return (a[sortItem] < b[sortItem]) ? 1 : ((b[sortItem] < a[sortItem]) ? -1 : 0);} )
           
        }else if(sortDirection=="down"){
            event.target.classList.remove("fa-sort-down");
            event.target.classList.add("fa-sort-up");
            this.sortDirection="up";
            this.allItems.sort(function(a,b) {return (a[sortItem] > b[sortItem]) ? 1 : ((b[sortItem] > a[sortItem]) ? -1 : 0);} )
           
        }
        // call pagination to set page
        event.target.classList.remove("fa-sort");
        this.setPage(1);
     }
  

      /*For pagination*/
      setPage(page: number) {
        
        this.message="";
        //this.amountSortIcon="fa-chevron-down";
        //this.sortDirection ="down";

        // get pager object from service
        this.pager = this.pagerService.getPager(this.allItems.length, page);

        // get current page of items
        this.pagedItems = this.allItems.slice(this.pager.startIndex, this.pager.endIndex + 1);

        if(this.allItems.length<1){
            this.message="No data found";
        }
    }
}
