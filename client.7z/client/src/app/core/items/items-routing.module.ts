import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ItemsComponent } from './items.component';
import { ItemDetailsComponent } from './item-details.component';
import { ItemListComponent } from './item-list.component';

const routes: Routes = [
    {
        path: '', component: ItemsComponent,
        children: [
           
            { path: 'item-list', component: ItemListComponent },
            { path: 'item-details/:_id', component: ItemDetailsComponent },

        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ItemsRoutingModule {
}
