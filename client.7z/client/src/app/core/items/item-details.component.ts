import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { ActivatedRoute } from '@angular/router';
import { ItemsService } from './items.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
    selector: 'app-form',
    templateUrl: './item-details.component.html',
    styleUrls: ['./items.component.scss'],
    animations: [routerTransition()]
})
export class ItemDetailsComponent implements OnInit {

    public itemDetails: any;
    public dataLoaded = false;
    constructor(private route: ActivatedRoute,private itemService : ItemsService) {}


    ngOnInit(): void {
        this.getItem();
      }
    
      getItem() {
        const itemId = this.route.snapshot.params._id;

        var item    =   JSON.stringify({"_id":itemId});
      /*  this.itemService._itemDetails(item).subscribe((data : any)=>{

            this.itemDetails =   data[0];
            if(this.itemDetails!=0){
                this.dataLoaded=false;
            }else{

            }
            
       },
       (err : HttpErrorResponse)=>{
        // this.isLoginError = true;
       })*/
      }

      
}
