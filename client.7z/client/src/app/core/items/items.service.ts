import { Injectable } from '@angular/core';
import {HttpService} from '../../shared/services/http.service';

@Injectable()
export class ItemsService {
  readonly rootUrl = 'http://localhost:5000/api/';
  readonly accessToken = localStorage.getItem('userToken');
  constructor(private http: HttpService) { }



_itemList() {
  var data={};
  return this.http.post(this.rootUrl + 'items/items',data).map((res) => {
    return res.json();
  });
    /*var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json;charset=utf-8','X-access-token': this.accessToken});
    return this.http.post(this.rootUrl + 'items/items',  { headers: reqHeader });*/
  }

  _itemDetails(item){
 /*   var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json;charset=utf-8'});
    return this.http.post(this.rootUrl + 'items/item-details', item, { headers: reqHeader });*/
  }


}
