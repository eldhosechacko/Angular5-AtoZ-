import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { ItemsService } from './items.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

import { PagerService } from '../components/pagination/index'

@Component({
    selector: 'app-items',
    templateUrl: './items.component.html',
    styleUrls: ['./items.component.scss'],
    animations: [routerTransition()]
})
export class ItemsComponent implements OnInit {
    public items: any;
    constructor(private itemsService : ItemsService,private pagerService: PagerService) {}

    

    // array of all items to be paged
    private allItems: any[];

    // pager object
    pager: any = {};

    // paged items
    pagedItems: any[];

    ngOnInit(){

     }

}
