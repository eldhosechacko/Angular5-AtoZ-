import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';



@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
  animations: [routerTransition()]
})
export class ProfileComponent implements OnInit {

  public fullname;

  constructor() { }

  ngOnInit() {
  }


  onSubmit() {
  //  var profileData=   {"username":userName,"password":password};
   /* this.userService._login(user).subscribe((data : any)=>{

      document.getElementById("loader").setAttribute("style", "display:none;");
      this.loggedUser     =   JSON.stringify(data.user);
     
      
      if(this.loggedUser){
          localStorage.setItem('auth_token',data.token);
          localStorage.setItem('loggedUser',this.loggedUser);
          this.onLoggedin();
          this.router.navigate(['/dashboard']);
      }else{
          this.errMessage =  JSON.stringify(data.message); 
      }
      
 },
 (err : HttpErrorResponse)=>{
  this.errMessage =  "Login attempt failed. Please try again later."; 
 });
    */
  }


}
