import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';


@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
    pushRightClass: string = 'push-right';
    public loggedUser: any;
    constructor(public router: Router) {

     
    }

    ngOnInit() {
        this.getLoggedUserData();
    }

    getLoggedUserData(){
        this.loggedUser =   JSON.parse(localStorage.getItem("loggedUser"));
    }

    onLoggedout() {
        localStorage.removeItem('isLoggedin');
    }

}
