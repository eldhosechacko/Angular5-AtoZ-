﻿export class AppSettings {
  //  public static apiUrl = '/api';
   public static apiUrl = 'http://localhost:5000/api';
   // public static apiUrl:string='/ECAPI/api';
    //public static apiUrl:string='https://m.np.ustdigitalqa.ust-global.com/api';

    public static admin = 'admin';
    public static engagement = 'Organization';
    public static portfolio = 'Account';
    public static project = 'Project';
    public static risks = 'risks';
    public static issues = 'issues';
    public static milestones = 'milestones';
    public static deliverables = 'deliverables';
    public static chartUpdates = 'updates';
    public static textUpdates = 'textUpdates';
    public static flags = 'flags';
    public static flagged = 'flagged';
    public static unFlagged = 'unFlagged';
    public static id = 'id';
    public static userSelected = 'userSelected';
    public static orgSelected = 'orgSelected';
    public static openIssues = 'Open Issues';
    public static closedIssues = 'Closed Issues';
    public static openRisks = 'Open Risks';
    public static closedRisks = 'Closed Risks';
}
